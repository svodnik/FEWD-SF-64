$('button').on('click', function () {
	$('img').fadeIn('slow');
});
